import sys,tempfile
from pathlib import Path
from datetime import date,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import run_all_districts as r
from scan_plan import *
m=r.load_source()
assert len(m.DISTRICTS)==5
for offset in range(366):
 t=date(2026,11,24)+timedelta(days=offset); ends=horizons(t); w=windows(t,ends)
 assert w[0][0]==t and w[-1][1]>=max(ends.values())
 assert all((b-a).days==30 for a,b in w)
 assert all(b+timedelta(days=1)>=c for (a,b),(c,d) in zip(w,w[1:]))
assert horizons(date(2026,11,24))=={'学校':date(2026,12,24),'スポーツ施設':date(2027,1,24),'いきいきプラザ':date(2027,1,31),'その他':date(2026,12,24)}
assert horizons(date(2026,12,4))['いきいきプラザ']==date(2027,1,31)
assert horizons(date(2026,12,5))['いきいきプラザ']==date(2027,2,28)
assert category('白金の丘学園')=='学校' and category('神応いきいきプラザ')=='いきいきプラザ' and category('スポーツセンター')=='スポーツ施設'
assert category('生涯学習センター（ばるーん）')=='その他'
# Archived district selector
root=Path(__file__).resolve().parents[1]
top=m.HtmlDocument((root/'evidence/fixture_top.html').read_text(encoding='cp932'))
assert all(m.option_value(top,'bname',d+'地区(すべて)') for d in m.DISTRICTS)
class Fake:
 DISTRICTS=m.DISTRICTS;DAY_CODES=m.DAY_CODES
 HttpSearch=staticmethod(lambda:object())
 @staticmethod
 def collect_district(client,d,a,b):
  if d=='高輪':raise TimeoutError('injected')
  t=r.datetime.now(r.JST).date()
  if a<=t+timedelta(days=40)<=b:
   return [{'地区':d,'施設名':'神応いきいきプラザ','施設コード':d,'区分コード':'1','日付':str(t+timedelta(days=40)),'開始':'09:00','終了':'12:00'}, {'地区':d,'施設名':'芝小学校','施設コード':d,'区分コード':'2','日付':str(t+timedelta(days=40)),'開始':'09:00','終了':'12:00'}]
  return []
with tempfile.TemporaryDirectory() as d:
 state=r.scan(Fake,Path(d)); assert len(state['slots'])==4
 assert all(x['施設種別']=='いきいきプラザ' for x in state['slots'])
 assert state['districts']['高輪']['学校']['状態']=='確認不能'
 assert state['districts']['芝浦港南']['学校']['状態']=='空きなし'
print('PASS: 366 dates, 5 districts, categories, deduplication, horizon filter, partial failure')
