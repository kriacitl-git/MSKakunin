import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from notify_v5 import *

def row(d,cat,day='2027-01-10'):
    return {'地区':d,'施設種別':cat,'施設・区分':'神応いきいきプラザ・体育室','日付':day,'開始':'09:00','終了':'12:00'}

def data(rows,partial=False):
    statuses={d:{c:{'状態':'空きあり' if any(r['地区']==d and r['施設種別']==c for r in rows) else '空きなし'} for c in CATEGORIES} for d in DISTRICTS}
    if partial:statuses['高輪']['スポーツ施設']['状態']='一部未確認'
    return {'地区別':statuses,'空き枠':rows}

r=row('高輪','いきいきプラザ'); r2=row('高輪','いきいきプラザ','2027-01-17'); r3=row('芝浦港南','スポーツ施設')
old={'高輪':[key(r)]}
assert key(r)==hashlib.sha256(json.dumps([r[k] for k in FIELDS],ensure_ascii=False).encode()).hexdigest()
new,st=changes(data([r,r3]),old);assert new==[r3] and st['高輪']==[key(r)]
new,st=changes(data([r2],True),old);assert new==[r2] and set(st['高輪'])=={key(r),key(r2)}
new,st2=changes(data([r2],True),st);assert new==[] and st2==st
new,st=changes(data([],True),old);assert new==[] and st['高輪']==[key(r)]
new,st=changes(data([],False),old);assert new==[] and st['高輪']==[]
assert changes({'地区別':{},'空き枠':[]},old)==([],old)
print('PASS: legacy keys, fifth district, dedup, partial failure, recovery')
