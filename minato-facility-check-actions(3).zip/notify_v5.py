"""Preserve v4 district-keyed state and notify only new confirmed vacancies."""
import hashlib
import json
import os
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from scan_plan import CATEGORIES

DISTRICTS = ('赤坂','高輪','麻布','芝','芝浦港南')
FIELDS = ('地区','施設・区分','日付','開始','終了')
COMPLETE = ('空きあり','空きなし')

def key(row):
    fields = [row[k] for k in FIELDS]
    if not all(isinstance(v,str) and v.strip() for v in fields):
        raise ValueError('invalid slot')
    return hashlib.sha256(json.dumps(fields, ensure_ascii=False).encode()).hexdigest()

def changes(data, old):
    current = dict(old)
    new = []
    for district in DISTRICTS:
        statuses = data.get('地区別',{}).get(district,{})
        rows = {}
        for row in data.get('空き枠',[]):
            if row.get('地区') != district:
                continue
            if row.get('施設種別') not in CATEGORIES:
                raise ValueError('unknown facility category')
            rows[key(row)] = row
        fully_checked = True
        for cat in CATEGORIES:
            info = statuses.get(cat,{})
            status = info.get('状態')
            count = sum(r['施設種別']==cat for r in rows.values())
            if status not in COMPLETE:
                fully_checked = False
            elif bool(count) != (status == '空きあり'):
                raise ValueError('category status mismatch')
        previous = set(old.get(district,[]))
        new.extend(row for k,row in rows.items() if k not in previous)
        # Partial failure must never erase previous keys for this district.
        if fully_checked:
            current[district] = sorted(rows)
        elif rows:
            current[district] = sorted(previous | set(rows))
    return new,current

def message(rows):
    lines = [f'🏐 新規空き：{len(rows)}件']
    link = '\n\n予約サイト：https://web101.rsv.ws-scs.jp/web/'
    run_url = os.environ.get('GITHUB_SERVER_URL','https://github.com') + '/' + os.environ.get('GITHUB_REPOSITORY','') + '/actions/runs/' + os.environ.get('GITHUB_RUN_ID','')
    for r in sorted(rows,key=lambda r:(r['日付'],r['開始'],r['地区'])):
        line = f"{r['地区']}｜{r['施設・区分']}\n{r['日付']}（{r.get('曜日','')}） {r['開始']}～{r['終了']}"
        if len(('\n\n'.join(lines+[line])+link+run_url).encode('utf-16-le'))//2 > 4200:
            lines.append('残りの枠は実行結果をご確認ください。\n'+run_url)
            break
        lines.append(line)
    return '\n\n'.join(lines)+link

def push(text):
    token, recipient = os.environ.get('LINE_CHANNEL_ACCESS_TOKEN'),os.environ.get('LINE_USER_ID')
    if not token or not recipient:
        raise RuntimeError('LINE secrets not configured')
    payload = json.dumps({'to':recipient,'messages':[{'type':'text','text':text}]},ensure_ascii=False).encode()
    req = Request('https://api.line.me/v2/bot/message/push',data=payload,headers={'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    try:
        with urlopen(req,timeout=20) as response:
            if response.status != 200:
                raise RuntimeError('LINE push failed')
    except HTTPError as e:
        raise RuntimeError(f'LINE HTTP {e.code}') from None
    except URLError:
        raise RuntimeError('LINE connection failed') from None

def main():
    if os.environ.get('TEST_LINE') == 'true':
        push('🏐 港区施設の空き通知：接続テスト成功')
        print('LINE test sent')
        return
    data = json.loads(Path(os.environ['RUNNER_TEMP'],'minato-result.json').read_text())
    state = Path('.minato-notified.json')
    old = json.loads(state.read_text()) if state.exists() else {}
    new,current = changes(data,old)
    if new:
        push(message(new))
    if current != old:
        state.write_text(json.dumps(current,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    print(f'New slots: {len(new)}')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        print(str(e) if isinstance(e,RuntimeError) else type(e).__name__,file=sys.stderr)
        sys.exit(1)
