from datetime import date, timedelta
import calendar
CATEGORIES=('学校','スポーツ施設','いきいきプラザ','その他')
def add_months(day,n):
    y,m=divmod(day.year*12+day.month-1+n,12); m+=1
    return date(y,m,min(day.day,calendar.monthrange(y,m)[1]))
def month_last(day):
    return day.replace(day=calendar.monthrange(day.year,day.month)[1])
def horizons(today):
    return {'学校':add_months(today,1),'スポーツ施設':add_months(today,2),'いきいきプラザ':month_last(add_months(today,2 if today.day>=5 else 1)),'その他':add_months(today,1)}
def windows(today,ends):
    end=max(ends.values()); starts=[today]
    while starts[-1]+timedelta(days=30)<end:
        starts.append(min(starts[-1]+timedelta(days=31),end-timedelta(days=30)))
    return [(s,s+timedelta(days=30)) for s in starts]
def category(name):
    if 'いきいきプラザ' in name:return 'いきいきプラザ'
    if any(x in name for x in ('小学校','中学校','学園')):return '学校'
    if any(x in name for x in ('スポーツセンター','運動場','武道場','野球場','アクアフィールド')):return 'スポーツ施設'
    return 'その他'
def relevant(ends,begin,finish):
    return [c for c in CATEGORIES if begin<=ends[c]]
