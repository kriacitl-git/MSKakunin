# 外部パッケージのインストールは不要。Python標準ライブラリのみ使用。


import calendar
import json
import re
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from html.parser import HTMLParser

class HtmlNode:
    def __init__(self, name='', attrs=()):
        self.name = name
        self.attrs = dict(attrs)
        self.children = []
    def get(self, name, default=None):
        value = self.attrs.get(name, default)
        return '' if value is None and name in self.attrs else value
    def has_attr(self, name):
        return name in self.attrs
    def find_all(self, names, **attrs):
        names = [names] if isinstance(names, str) else names
        found = []
        for child in self.children:
            if isinstance(child, HtmlNode):
                if child.name in names and all(child.has_attr(k) if v is True else child.get(k)==v for k,v in attrs.items()):
                    found.append(child)
                found.extend(child.find_all(names, **attrs))
        return found
    def find(self, names, **attrs):
        found = self.find_all(names, **attrs)
        return found[0] if found else None
    def get_text(self, strip=False):
        value = ''.join(c.get_text() if isinstance(c, HtmlNode) else c for c in self.children)
        return value.strip() if strip else value

class HtmlDocument(HTMLParser, HtmlNode):
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self, raw):
        HtmlNode.__init__(self)
        HTMLParser.__init__(self, convert_charrefs=True)
        self.stack = [self]
        self.feed(raw)
        self.close()
    def handle_starttag(self, name, attrs):
        node = HtmlNode(name, attrs)
        self.stack[-1].children.append(node)
        if name not in self.VOID:
            self.stack.append(node)
    def handle_startendtag(self, name, attrs):
        self.handle_starttag(name, attrs)
        if name not in self.VOID:
            self.handle_endtag(name)
    def handle_endtag(self, name):
        for i in range(len(self.stack)-1, 0, -1):
            if self.stack[i].name == name:
                del self.stack[i:]
                break
    def handle_data(self, data):
        self.stack[-1].children.append(data)


URL = "https://web101.rsv.ws-scs.jp/web/"
DAY_CODES = ('6','7','9')
DISTRICTS = ("赤坂", "高輪", "麻布", "芝", "芝浦港南")
OUTPUT = Path("output")
TIMEOUT = 20
JST = ZoneInfo("Asia/Tokyo")

class VerificationError(RuntimeError):
    pass

def month_end(start):
    year = start.year + (start.month == 12)
    month = start.month % 12 + 1
    return date(year, month, min(start.day, calendar.monthrange(year, month)[1]))

def resolve_date(month, day, start, end, year=None):
    years = [int(year)] if year else range(start.year, end.year + 1)
    candidates = []
    for y in years:
        try:
            candidate = date(y, int(month), int(day))
        except ValueError:
            continue
        if start <= candidate <= end:
            candidates.append(candidate)
    if len(candidates) != 1:
        raise VerificationError("検索期間外または不明な日付")
    return candidates[0]









def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


import http.cookiejar
import urllib.request
import urllib.parse

class HttpSearch:
    """公開検索だけを送信する。ブラウザーもJavaScript実行も不要。"""
    def __init__(self):
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        self.page_source = ""
        self.top = self.fetch(URL)
        scripts = " ".join(s.get_text() for s in self.top.find_all('script'))
        self.actions = {}
        for name in ('gRsvWOpeInstSrchVacantAction', 'gRsvWOpeUnreservedDailyAction'):
            match = re.search(r"var\s+" + name + r"\s*=\s*['\"]([^'\"]+)['\"]", scripts)
            if not match:
                raise VerificationError('公開検索の送信先がありません: ' + name)
            target = urllib.parse.urljoin(URL, match[1])
            if urllib.parse.urlsplit(target).netloc != urllib.parse.urlsplit(URL).netloc:
                raise VerificationError('検索送信先が別ホストです')
            self.actions[name] = target

    def fetch(self, url, pairs=None):
        payload = urllib.parse.urlencode(pairs, encoding='cp932').encode('ascii') if pairs is not None else None
        response = self.opener.open(url, data=payload, timeout=TIMEOUT)
        if urllib.parse.urlsplit(response.url).netloc != urllib.parse.urlsplit(URL).netloc:
            raise VerificationError('別ホストへ転送されました')
        charset = response.headers.get_content_charset() or 'cp932'
        if charset.lower().replace('_','-') in ('windows-31j', 'ms932', 'shift-jis'):
            charset = 'cp932'
        raw = response.read().decode(charset)
        soup = HtmlDocument(raw)
        self.page_source = raw
        return soup

    def quit(self):
        pass

def form_data(soup):
    form = soup.find('form')
    if not form:
        raise VerificationError('フォームがありません')
    pairs = []
    for field in form.find_all(['input','select']):
        name = field.get('name')
        if not name or field.has_attr('disabled'):
            continue
        if field.name == 'input':
            kind = field.get('type','text')
            if kind in ('button','submit','reset','file'):
                continue
            if kind in ('checkbox','radio') and not field.has_attr('checked'):
                continue
            pairs.append((name,field.get('value','')))
        else:
            selected = field.find('option',selected=True) or field.find('option')
            if selected:
                pairs.append((name,selected.get('value','')))
    return pairs

def option_value(soup, select_id, label):
    select = soup.find('select',id=select_id)
    options = [] if not select else [x for x in select.find_all('option') if x.get_text(strip=True)==label]
    if len(options)!=1:
        raise VerificationError('選択肢が特定できません: '+label)
    return options[0].get('value')

def collect_district(client, district, start, end):
    area = option_value(client.top,'bname',district+'地区(すべて)')
    purpose = option_value(client.top,'purpose','バドミントン')
    overrides = {'date':'4','daystart':start.isoformat(),'days':'31',
                 'selectAreaBcd':area,'selectIcd':'0','selectPpsClPpscd':purpose,
                 'dayofweekClearFlg':'0','timezoneClearFlg':'1'}
    params = [(k,v) for k,v in form_data(client.top) if k not in overrides and k not in ('dayofweek','timezone')]
    params += list(overrides.items()) + [('dayofweek',x) for x in DAY_CODES]
    result = client.fetch(client.actions['gRsvWOpeInstSrchVacantAction'],params)
    # 返ってきたフォームの選択状態で、要求条件が実際に保持されたか確認。
    actual = form_data(result)
    for name,value in overrides.items():
        if name in ('date','dayofweekClearFlg','timezoneClearFlg'):
            continue
        if (name,value) not in actual:
            raise VerificationError('返却された検索条件が不一致: '+name)
    if {v for k,v in actual if k=='dayofweek'} != set(DAY_CODES) or any(k=='timezone' for k,v in actual):
        raise VerificationError('曜日/時間帯条件が不一致')
    result = client.fetch(client.actions['gRsvWOpeUnreservedDailyAction'],actual)
    scripts = ' '.join(s.get_text() for s in result.find_all('script'))
    action_match = re.search(r'var\s+formAction\s*=\s*[\'"]([^\'"]+)[\'"]', scripts)
    data_match = re.search(r'var\s+formData\s*=\s*(\{.*?\});', scripts)
    if not action_match or not data_match:
        raise VerificationError('空きデータ取得の定義がありません')
    action = urllib.parse.urljoin(URL,action_match[1])
    if urllib.parse.urlsplit(action).netloc != urllib.parse.urlsplit(URL).netloc:
        raise VerificationError('データ取得先が別ホストです')
    data = json.loads(data_match[1])
    if (data.get('selectAreaBcd')!=area or data.get('selectPpsClPpscd')!=purpose
        or data.get('daystart')!=start.isoformat() or int(data.get('days',0))!=31
        or {str(v) for v in data.get('dayofweek',[])}!=set(DAY_CODES)
        or data.get('timezone') not in ([],None)):
        raise VerificationError('データ取得条件が不一致')
    records = {}
    for page in range(30):
        pairs = []
        for key,value in data.items():
            if isinstance(value,list):
                pairs.extend((key,v) for v in value)
            else:
                pairs.append((key,value))
        req = urllib.request.Request(action,data=urllib.parse.urlencode(pairs,encoding='cp932').encode(),
                                     headers={'X-Requested-With':'XMLHttpRequest'})
        response = client.opener.open(req,timeout=TIMEOUT)
        raw = response.read()
        payload = json.loads(raw.decode('cp932'))
        client.page_source = json.dumps(payload,ensure_ascii=False,indent=2)
        if 'ErrManager' in payload:
            raise VerificationError(str(payload['ErrManager']))
        if not isinstance(payload.get('results'),list) or 'all' not in payload:
            raise VerificationError('空きデータの形式が不正です')
        all_count = int(payload['all'])
        if all_count == 0:
            if records or payload.get('results'):
                raise VerificationError('件数とデータが矛盾しています')
            return []
        for record in payload.get('results',[]):
            key = tuple(str(record.get(k,'')) for k in ('useYmd','bcd','icd','sTime','eTime'))
            records[key] = record
        next_offset = int(payload.get('next',0))
        if all_count <= next_offset-1:
            break
        if next_offset <= int(data.get('offset',0)):
            raise VerificationError('ページ送りが進みません')
        data['offset'] = next_offset
    else:
        raise VerificationError('ページ取得上限を超えました')
    if len(records)!=all_count:
        raise VerificationError(f'取得件数不一致: {len(records)}/{all_count}')
    rows = []
    for record in records.values():
        day = datetime.strptime(str(record['useYmd']),'%Y%m%d').date()
        if not start<=day<=end:
            raise VerificationError('期間外の空きデータ')
        if str(day.weekday()+1) not in DAY_CODES and not ('9' in DAY_CODES and str(record.get('holidayFlg'))=='4'):
            raise VerificationError('曜日条件外の空きデータ')
        def normal_time(value):
            match = re.fullmatch(r'(\d{1,2})[:：](\d{2})',str(value))
            if not match:
                raise VerificationError('時間形式が不明です')
            h,m = map(int,match.groups())
            if not (0<=h<=24 and 0<=m<60 and (h!=24 or m==0)):
                raise VerificationError('時間が不正です')
            return f'{h:02d}:{m:02d}'
        begin,finish = normal_time(record['sJTime2']),normal_time(record['eJTime2'])
        if begin>=finish:
            raise VerificationError('開始終了が不正です')
        rows.append({'地区':district,'日付':day.isoformat(),'曜日':'月火水木金土日'[day.weekday()],
                     '施設名':record['bcdNm'],'施設コード':str(record['bcd']), '区分コード':str(record['icd']), '施設・区分':record['bcdNm']+'・'+record['icdNm'],'開始':begin,'終了':finish})
    return rows


def run():
    start = datetime.now(JST).date()
    end = month_end(start)
    client = HttpSearch()
    records, statuses = [], {}
    for district in DISTRICTS:
        try:
            rows = collect_district(client, district, start, end)
            records.extend(rows)
            statuses[district] = {"状態": "空きあり" if rows else "空きなし", "件数": len(rows)}
        except Exception as exc:
            statuses[district] = {"状態": "確認不能", "理由": f"{type(exc).__name__}: {exc}"[:300]}
    result = {"対象期間": [start.isoformat(), end.isoformat()], "地区別": statuses,
              "空き枠": sorted(records, key=lambda r: (r["日付"], r["開始"], r["地区"]))}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result
