import json,sys
from pathlib import Path
from notify_v5 import DISTRICTS,COMPLETE
from scan_plan import CATEGORIES

def summary(data):
    rows=data.get('空き枠',[])
    districts=data.get('地区別',{})
    statuses=[districts.get(d,{}).get(c,{}).get('状態','未確認') for d in DISTRICTS for c in CATEGORIES]
    complete=sum(s in COMPLETE for s in statuses)
    any_checked=complete or rows or any(districts.get(d,{}).get(c,{}).get('成功期間') for d in DISTRICTS for c in CATEGORIES)
    if complete==len(statuses) and not data.get('エラー'):
        print(f'空き：{len(rows)}件')
    elif any_checked:
        print(f'確認できた空き：{len(rows)}件（一部未確認）')
    else:
        print('空き件数：未確認')
    print('確認日時：',data.get('確認日時') or '未確認')
    ends=(data.get('対象条件') or {}).get('end_by_category',{})
    for cat in CATEGORIES:
        rs=[r for r in rows if r.get('施設種別')==cat]
        print(f"- {cat}：{len(rs)}件（期限：{ends.get(cat,'未確認')}）")
    print('\n地区別確認状態：')
    for d in DISTRICTS:
        print('- '+d+'：'+' / '.join(c+' '+districts.get(d,{}).get(c,{}).get('状態','未確認') for c in CATEGORIES))
    for r in sorted(rows,key=lambda x:(x['日付'],x['開始'],x['地区'])):
        print(f"- {r['地区']}｜{r['施設・区分']}｜{r['日付']} {r.get('曜日','')} {r['開始']}～{r['終了']}")
    for err in data.get('エラー',[]):
        print(f"- エラー：{err.get('phase','不明')} / {err.get('exception_type','不明')}")

if __name__=='__main__':
    summary(json.loads(Path(sys.argv[1]).read_text()))
