import json, sys
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

def summarize(data):
    districts = data.get('地区別', {})
    names = ('赤坂', '高輪', '麻布', '芝')
    ok = [n for n in names if districts.get(n, {}).get('状態') in ('空きあり','空きなし')]
    rows = data.get('空き枠', [])
    errors = data.get('エラー', [])
    count = len(rows)
    if len(ok) == 4 and not errors:
        first = f'空き：{count}件'
    elif ok:
        first = f'確認できた空き：{count}件（一部未確認）'
    else:
        first = '空き件数：未確認'
    conditions = data.get('対象条件') or {}
    lines = ['## '+first, '確認日時：'+datetime.now(ZoneInfo('Asia/Tokyo')).strftime('%Y-%m-%d %H:%M JST'),
             f"対象期間：{conditions.get('start','未確認')} ～ {conditions.get('end','未確認')}（土日祝・全時間帯・バドミントン）", '']
    for n in names:
        lines.append(f"- {n}：{districts.get(n, {}).get('状態','未確認')}")
    if rows:
        lines.extend(['', '| 地区 | 施設・区分 | 日付 | 時間 |','|---|---|---|---|'])
        for row in sorted(rows, key=lambda r: (r['日付'],r['開始'],r['地区'])):
            cells = [row['地区'],row['施設・区分'],row['日付']+'（'+row['曜日']+'）',row['開始']+'～'+row['終了']]
            lines.append('| '+' | '.join(str(c).replace('|','&#124;').replace('\n',' ') for c in cells)+' |')
    for err in errors:
        lines.append(f"- エラー：{err.get('phase','不明')} / {err.get('exception_type','不明')}")
    return '\n'.join(lines)+'\n'

if __name__ == '__main__':
    try:
        data = json.loads(Path(sys.argv[1]).read_text())
    except (OSError, ValueError):
        data = {'エラー':[{'phase':'結果読込','exception_type':'MissingOrInvalidResult'}]}
    print(summarize(data))
