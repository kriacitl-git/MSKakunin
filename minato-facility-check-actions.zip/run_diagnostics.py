#!/usr/bin/env python3
"""標準ライブラリのみ。既存v4検索の診断用ランナー（通常4地区専用）。"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback
from datetime import datetime
from urllib.parse import urlsplit
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'original/search_v4.py'
JST = ZoneInfo('Asia/Tokyo')

def now():
    return datetime.now(JST).isoformat()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)

def safe_error(exc):
    # tracebacks retain source locations; omit arbitrary remote error bodies/messages.
    return {'exception_type': type(exc).__name__,
            'http_status': getattr(exc, 'code', None),
            'errno': getattr(exc, 'errno', None),
            'frames': [{'file': Path(f.filename).name, 'line': f.lineno, 'function': f.name}
                       for f in traceback.extract_tb(exc.__traceback__)]}

def validate_json_body(raw):
    payload = json.loads(raw.decode('cp932'))
    if not isinstance(payload, dict) or 'all' not in payload or not isinstance(payload.get('results'), list):
        raise ValueError('INVALID_JSON_RESULTS_SCHEMA')
    if int(payload['all']) < 0:
        raise ValueError('NEGATIVE_RESULT_COUNT')
    return payload

def load_source():
    manifest = json.loads((ROOT/'manifest.json').read_text())
    actual = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    if actual != manifest['files']['original/search_v4.py']['sha256']:
        raise RuntimeError('SOURCE_HASH_MISMATCH')
    spec = importlib.util.spec_from_file_location('search_v4', SOURCE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def scan(module, dest):
    state = {'started_at': now(), 'finished_at': None, 'phase': 'initialization',
             'python': platform.python_version(), 'platform': platform.system(),
             'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
             'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'districts': {d: {'状態': '未確認'} for d in module.DISTRICTS},
             'slots': [], 'http': [], 'errors': []}
    def checkpoint():
        write(dest/'diagnostic.json', state)
    checkpoint()
    # Record public endpoint paths/status/response hashes only. Never save cookies,
    # tokens, headers, query strings or HTML response bodies.
    import urllib.request
    build = urllib.request.build_opener
    class Response:
        def __init__(self, response, event, ajax=False):
            self.response, self.event, self.ajax = response, event, ajax
        def __getattr__(self, key):
            return getattr(self.response, key)
        def read(self, *args):
            try:
                raw = self.response.read(*args)
                self.event.update(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), state='body_received')
                if self.ajax:
                    payload = validate_json_body(raw)
                    self.event['result_summary'] = {'all':payload['all'], 'next':payload.get('next'),
                                                   'returned_rows':len(payload['results'])}
                else:
                    charset = self.response.headers.get_content_charset() or 'cp932'
                    if charset.lower().replace('_','-') in ('windows-31j','ms932','shift-jis'):
                        charset='cp932'
                    doc = module.HtmlDocument(raw.decode(charset))
                    allowed={'daystart','days','dayofweek','timezone','selectAreaBcd','selectIcd','selectPpsClPpscd'}
                    self.event['returned_filters'] = [(k,v) for k,v in module.form_data(doc) if k in allowed] if doc.find('form') else []
                return raw
            except Exception as exc:
                self.event.update(state='read_or_schema_failed', error=safe_error(exc))
                raise
            finally:
                checkpoint()
    class Opener:
        def __init__(self, inner):
            self.inner = inner
        def open(self, target, *args, **kwargs):
            url = target.full_url if hasattr(target, 'full_url') else target
            parsed = urlsplit(url)
            event = {'phase': state['phase'], 'at': now(), 'host': parsed.hostname,
                     'path': parsed.path, 'state': 'started'}
            state['http'].append(event)
            checkpoint()
            started = time.monotonic()
            try:
                response = self.inner.open(target, *args, **kwargs)
                event.update(state='headers_received', status=response.status,
                             content_type=response.headers.get_content_type())
                if urlsplit(response.url).netloc != urlsplit(module.URL).netloc:
                    raise ValueError('UNEXPECTED_RESPONSE_HOST')
                ajax = hasattr(target, 'header_items') and any(k.lower()=='x-requested-with' for k,v in target.header_items())
                return Response(response, event, ajax)
            except Exception as exc:
                event.update(state='failed', error=safe_error(exc))
                raise
            finally:
                event['header_elapsed_seconds'] = round(time.monotonic()-started, 3)
                checkpoint()
    urllib.request.build_opener = lambda *a, **kw: Opener(build(*a, **kw))
    try:
        start = datetime.now(JST).date()
        end = module.month_end(start)
        state['requested'] = {'start': str(start), 'end': str(end), 'days_sent': 31,
                              'day_codes': list(module.DAY_CODES), 'purpose': 'バドミントン'}
        client = module.HttpSearch()
        for district in module.DISTRICTS:
            state['phase'] = district
            checkpoint()
            try:
                rows = module.collect_district(client, district, start, end)
                state['slots'].extend(rows)
                state['districts'][district] = {'状態': '空きあり' if rows else '空きなし', '件数':len(rows)}
            except Exception as exc:
                error = {'phase': district, **safe_error(exc)}
                state['errors'].append(error)
                state['districts'][district] = {'状態':'確認不能', 'error':error}
                checkpoint()
                if isinstance(exc, (OSError, TimeoutError)):
                    break
            checkpoint()
    except Exception as exc:
        state['errors'].append({'phase':state['phase'], **safe_error(exc)})
    finally:
        urllib.request.build_opener = build
        state['finished_at'] = now()
        state['phase'] = 'finished'
        checkpoint()
    return state

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--output', type=Path, default=ROOT/'runs'/datetime.now(JST).strftime('%Y%m%dT%H%M%S_%f'))
    parser.add_argument('--deadline', type=int, default=150)
    parser.add_argument('--audit', action='store_true', help='成功時も今回の点検証跡を残す')
    args = parser.parse_args()
    if args.worker:
        try:
            scan(load_source(), args.output)
        except Exception as exc:
            write(args.output/'diagnostic.json', {'phase':'load_source', 'errors':[safe_error(exc)]})
        return
    args.output.mkdir(parents=True, exist_ok=True)
    try:
        proc = subprocess.run([sys.executable, str(Path(__file__).resolve()), '--worker', '--output', str(args.output.resolve())],
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=args.deadline)
        terminal = None if proc.returncode == 0 else {'exception_type':'WorkerExit', 'exit_code':proc.returncode}
    except subprocess.TimeoutExpired:
        terminal = {'exception_type':'OverallDeadlineExceeded', 'deadline_seconds':args.deadline}
    path = args.output/'diagnostic.json'
    state = json.loads(path.read_text()) if path.exists() else {'errors':[], 'phase':'before_checkpoint'}
    if terminal:
        state.setdefault('errors',[]).append({'phase':state['phase'], **terminal})
        state['finished_at'] = now()
        write(path, state)
    failed = bool(state.get('errors')) or any(v['状態'] in ('未確認','確認不能') for v in state.get('districts',{}).values())
    print(json.dumps({'対象条件':state.get('requested'), '地区別':state.get('districts',{}),
                      '空き枠':state.get('slots',[]), 'エラー':state.get('errors',[]),
                      '証跡':str(path.resolve()) if failed or args.audit else None}, ensure_ascii=False, indent=2))
    if not failed and not args.audit:
        path.unlink(missing_ok=True)
        args.output.rmdir()
    return 2 if failed else 0

if __name__ == '__main__':
    sys.exit(main())
