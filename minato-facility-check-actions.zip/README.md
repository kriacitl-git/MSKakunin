# 港区4地区の空き確認（手動実行）

既存の公開検索コードと診断ランナーを変更せず使用します。土日祝・バドミントン・全時間帯・赤坂/高輪/麻布/芝、実行日から1か月先。ログイン・予約・支払いなし。手動起動のみ、再試行なし、150秒上限。BGSのサイト・会員データ・定期実行とは独立しています。

## GitHubへの登録
1. https://github.com/new で別の空リポジトリを作成（例: minato-facility-check）。公開範囲は自身で決定。公開の場合はコード・実行結果も公開されます。非公開の場合はGitHub Actionsの利用枠が必要です。
2. ZIPを展開し、隠しディレクトリ `.github` を含む全ファイルをリポジトリの既定ブランチに追加・コミットします。PCでGitを使う場合は、作成した空リポジトリのURLをコピーし、展開ディレクトリで `git init -b main`、`git add .`、`git commit -m "Add manual facility check"`、`git remote add origin <リポジトリURL>`、`git push -u origin main` を実行します。
3. GitHubの Actions → 港区4地区の空き確認 → Run workflow で手動起動。実行詳細の Summary に結果が出ます。

## ローカル実行
Python 3.9以上とAsia/Tokyoのタイムゾーンデータが必要です。追加のPythonパッケージ不要。`python3 run_diagnostics.py --deadline 150` で一度検索できます。失敗時は未確認扱いです。

## 注意
外部接続が可能な環境が必要です。GitHub上での実通信は未検証。定期実行は追加していません。公開リポジトリにする場合は、収録内容が公開されることを理解したうえで設定してください。
